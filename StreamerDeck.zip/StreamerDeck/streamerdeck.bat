@echo off
start chrome --app=https://Ege352.github.io/stream-deck/
exit